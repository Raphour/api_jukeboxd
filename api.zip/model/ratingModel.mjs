export default class Rating {
  get rate() {
    return this._rate;
  }

  set rate(value) {
    this._rate = value;
  }

  get review() {
    return this._review;
  }

  set review(value) {
    this._review = value;
  }

  get typeOfContent() {
    return this._typeOfContent;
  }

  set typeOfContent(value) {
    this._typeOfContent = value;
  }
    constructor(obj) {
      // Extract and validate properties
      const { id, rate, review, typeOfContent } = obj;
  
      if (!id || typeof id !== 'number') {
        throw new TypeError('Invalid id: must be a number');
      }
  
      if (!rate || typeof rate !== 'number' || rate < 0 || rate > 5) {
        throw new TypeError('Invalid rate: must be a number between 0 and 5');
      }
  
      if ( typeof review !== 'string') {
        throw new TypeError('Invalid review: must be a string');
      }
  
      if (!typeOfContent || typeof typeOfContent !== 'string' || (typeOfContent !== 'song' && typeOfContent !== 'album')) {
        throw new TypeError('Invalid typeOfContent: must be "song" or "album"');
      }
  
      // Store validated data in properties
      this.id = id;
      this._rate = rate;
      this._review = review || null;
      this._typeOfContent = typeOfContent;
    }


  }
  